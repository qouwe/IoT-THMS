/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "dht.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
/* Definitions for DHT_Task */
osThreadId_t DHT_TaskHandle;
const osThreadAttr_t DHT_Task_attributes = {
  .name = "DHT_Task",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityHigh,
};
/* Definitions for OLED_Task */
osThreadId_t OLED_TaskHandle;
const osThreadAttr_t OLED_Task_attributes = {
  .name = "OLED_Task",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for Key_Task */
osThreadId_t Key_TaskHandle;
const osThreadAttr_t Key_Task_attributes = {
  .name = "Key_Task",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityAboveNormal,
};
/* Definitions for WiFi_Task */
osThreadId_t WiFi_TaskHandle;
const osThreadAttr_t WiFi_Task_attributes = {
  .name = "WiFi_Task",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityAboveNormal,   // �� Low �� AboveNormal
};
/* Definitions for StatusLEDTask */
osThreadId_t StatusLEDTaskHandle;
const osThreadAttr_t StatusLEDTask_attributes = {
  .name = "StatusLEDTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for WatchDogTask */
osThreadId_t WatchDogTaskHandle;
const osThreadAttr_t WatchDogTask_attributes = {
  .name = "WatchDogTask",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for Queue_OLED */
osMessageQueueId_t Queue_OLEDHandle;
const osMessageQueueAttr_t Queue_OLED_attributes = {
  .name = "Queue_OLED"
};
/* Definitions for Queue_WiFi */
osMessageQueueId_t Queue_WiFiHandle;
const osMessageQueueAttr_t Queue_WiFi_attributes = {
  .name = "Queue_WiFi"
};
/* Definitions for Sem_Key */
osSemaphoreId_t Sem_KeyHandle;
const osSemaphoreAttr_t Sem_Key_attributes = {
  .name = "Sem_Key"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDHTTask(void *argument);
void StartOLEDTask(void *argument);
void StartKeyTask(void *argument);
void StartWiFiTask(void *argument);
void StartStatusLEDTask(void *argument);
void StartWatchDogTask(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* Hook prototypes */
void vApplicationStackOverflowHook(xTaskHandle xTask, signed char *pcTaskName);

/* USER CODE BEGIN 4 */
static void uart1_puts(const char *s)
{
  if (s == NULL) return;
  while (*s != '\0') {
    while ((USART1->SR & USART_SR_TXE) == 0u) {
    }
    USART1->DR = (uint8_t)*s++;
  }
}

void vApplicationStackOverflowHook(xTaskHandle xTask, signed char *pcTaskName)
{
  (void)xTask;
  uart1_puts("\r\nSTACK ");
  uart1_puts((const char *)pcTaskName);
  uart1_puts("\r\n");
  for (;;) {
    GPIOC->ODR ^= GPIO_ODR_ODR13;
    for (volatile uint32_t i = 0; i < 200000u; i++) {
    }
  }
}
/* USER CODE END 4 */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* creation of Sem_Key */
  Sem_KeyHandle = osSemaphoreNew(1, 0, &Sem_Key_attributes);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of Queue_OLED */
  Queue_OLEDHandle = osMessageQueueNew (1, sizeof(DHT_Data_t), &Queue_OLED_attributes);

  /* creation of Queue_WiFi */
  Queue_WiFiHandle = osMessageQueueNew (10, sizeof(DHT_Data_t), &Queue_WiFi_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of DHT_Task */
  DHT_TaskHandle = osThreadNew(StartDHTTask, NULL, &DHT_Task_attributes);

  /* creation of OLED_Task */
  OLED_TaskHandle = osThreadNew(StartOLEDTask, NULL, &OLED_Task_attributes);

  /* creation of Key_Task */
  Key_TaskHandle = osThreadNew(StartKeyTask, NULL, &Key_Task_attributes);

  /* creation of WiFi_Task */
  WiFi_TaskHandle = osThreadNew(StartWiFiTask, NULL, &WiFi_Task_attributes);

  /* creation of StatusLEDTask */
  StatusLEDTaskHandle = osThreadNew(StartStatusLEDTask, NULL, &StatusLEDTask_attributes);

  /* creation of WatchDogTask */
  WatchDogTaskHandle = osThreadNew(StartWatchDogTask, NULL, &WatchDogTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDHTTask */
/**
  * @brief  Function implementing the DHT_Task thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDHTTask */
__weak void StartDHTTask(void *argument)
{
  /* USER CODE BEGIN StartDHTTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDHTTask */
}

/* USER CODE BEGIN Header_StartOLEDTask */
/**
* @brief Function implementing the OLED_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartOLEDTask */
__weak void StartOLEDTask(void *argument)
{
  /* USER CODE BEGIN StartOLEDTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartOLEDTask */
}

/* USER CODE BEGIN Header_StartKeyTask */
/**
* @brief Function implementing the Key_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartKeyTask */
__weak void StartKeyTask(void *argument)
{
  /* USER CODE BEGIN StartKeyTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartKeyTask */
}

/* USER CODE BEGIN Header_StartWiFiTask */
/**
* @brief Function implementing the WiFi_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartWiFiTask */
__weak void StartWiFiTask(void *argument)
{
  /* USER CODE BEGIN StartWiFiTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartWiFiTask */
}

/* USER CODE BEGIN Header_StartStatusLEDTask */
/**
* @brief Function implementing the StatusLEDTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartStatusLEDTask */
__weak void StartStatusLEDTask(void *argument)
{
  /* USER CODE BEGIN StartStatusLEDTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartStatusLEDTask */
}

/* USER CODE BEGIN Header_StartWatchDogTask */
/**
* @brief Function implementing the WatchDogTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartWatchDogTask */
__weak void StartWatchDogTask(void *argument)
{
  /* USER CODE BEGIN StartWatchDogTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartWatchDogTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

